:stylesheet: test

.. checkbox::

.. editable:: Editez moi !
