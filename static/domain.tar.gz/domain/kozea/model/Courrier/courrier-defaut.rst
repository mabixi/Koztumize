:stylesheet: courrier-defaut

.. editable:: Date

.. editable:: Destinataire

Reference
  .. editable:: Ref

Objet
  .. editable:: Obj

.. editable:: Civilites


.. editable:: Corps


.. editable:: Formule de salutation
