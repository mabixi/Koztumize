:stylesheet: Tiers payant

.. editable:: Date

.. editable:: Nom destinataire

.. editable:: Adresse destinataire

Mandaté par :

.. editable:: Nom de la Pharmacie et Adresse mandataire


===============  ==========================
Objet :          .. editable:: Objet
Bénéficiaire:    .. editable:: Bénéficiaire
Référence :      .. editable:: Référence
===============  ==========================




.. editable:: Civilités

À la suite d'un refus de paiement par la caisse

.. editable:: Nom de la caisse

du dossier de dispense d'avance de frais médicaux (tiers payant) dont vous avez bénéficié, nous vous invitons à vous rendre à la pharmacie muni des documents suivants ou de nous les faire parvenir par tout moyen à votre convenance :

==============  ==============================  ==============================
.. checkbox::    Attestation Vitale valide en    .. editable:: Date validité
.. checkbox::       Attestation CMU valide en    .. editable:: Date validité
.. checkbox::        Carte mutuelle valide en    .. editable:: Date validité
.. checkbox::                        Autre...    .. editable:: Précisez
==============  ==============================  ==============================

À défaut de pouvoir fournir les documents demandés, nous vous remercions de bien vouloir régler directement la pharmacie la somme rejetée par votre caisse et restant due, à savoir

.. editable:: Règlement (en €)

€.

À reception de votre paiement, nous vous adresserons une feuille de soin vous permettant le cas échéant de vous faire rembourser par votre caisse. Dans l'attente de vos nouvelles et en vous remerciant pour votre compréhension, soyez assuré,Madame, Monsieur, de toujours pouvoir bénéficier du meilleur service dans notre officine.
