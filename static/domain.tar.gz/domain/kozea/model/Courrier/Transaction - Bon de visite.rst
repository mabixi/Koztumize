:stylesheet: Tiers payant

Carte professionnelle n°082844 / Organisme de garantie : S.O.C.A.F.

Je soussigné(e),

Prénom :

.. editable:: Prénom du visiteur

Nom :

.. editable:: Nom du visiteur

Domicile :

.. editable:: Domicile du visiteur

Téléphone :

.. editable:: Téléphone du visiteur

Courriel :

.. editable:: Courriel du visiteur

Reconnais avoir demandé et reçu à l'instant de votre cabinet les noms, adresses et conditions de négociation de l'affaire désignée ci-dessous et l'avoir visité en votre compagnie.

.. editable:: Nom de la pharmacie

.. editable:: Rue de la pharmacie

.. editable:: Code postal de la pharmacie

.. editable:: Ville de la pharmacie

En conséquence et à ce titre, je m'engage expressément :


 A ne communiquer à personne ces renseignements qui me sont donnés à titre personnel et confidentiel,

 A informer de notre visite de ce jour toute personne qui pourrait à l'avenir me présenter le même bien,

 A m'interdir toute entente avec le vendeur ayant pour conséquence de vous évincer lors de l'achat de cette affaire.


Je déclare avoir été informé(e) qu'à défaut du respect de ces engagements le présent document pourra être utilisé comme moyen de preuve de la diligence du cabinet et de l'origine du client à l'égard du vendeur afin que le professionnel de l'immobilier, désigné ci-avant, fasse valoir ses droits à honoraires.

Fait en 2 exemplaires, dont un remis au visiteur qui le reconnaît et en donne décharge à la société KELEOS.

A, 

.. editable:: lieu

le

.. editable:: Date                   

Signatures, précédées de la mention "lu et approuvé"
                  
             Le visiteur

.. editable:: Représentant Keleos

